#ifndef ANGEH_RUNTIME_H
#define ANGEH_RUNTIME_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef enum {
    VAL_INT,
    VAL_FLOAT,
    VAL_STRING,
    VAL_NIL,
    VAL_BOOL,
    VAL_LIST
} ValType;

struct AngehVal;
typedef struct AngehList {
    int length;
    int capacity;
    struct AngehVal* items;
} AngehList;

typedef struct AngehVal {
    ValType type;
    union {
        long long i;
        double f;
        char* str;
        int boolean;
        AngehList* list;
    } as;
} AngehVal;

static AngehVal make_int(long long i) { AngehVal v; v.type = VAL_INT; v.as.i = i; return v; }
static AngehVal make_float(double f) { AngehVal v; v.type = VAL_FLOAT; v.as.f = f; return v; }
static AngehVal make_string(const char* s) { 
    AngehVal v; v.type = VAL_STRING; 
    // Remove quotes if present
    if (s[0] == '"' && s[strlen(s)-1] == '"') {
        v.as.str = strndup(s+1, strlen(s)-2);
    } else {
        v.as.str = strdup(s); 
    }
    return v; 
}
static AngehVal make_nil() { AngehVal v; v.type = VAL_NIL; return v; }
static AngehVal make_bool(int b) { AngehVal v; v.type = VAL_BOOL; v.as.boolean = b; return v; }

static AngehVal make_list(int count, ...) {
    AngehVal v; 
    v.type = VAL_LIST;
    v.as.list = (AngehList*)malloc(sizeof(AngehList));
    v.as.list->length = 0;
    v.as.list->capacity = count > 0 ? count : 4;
    v.as.list->items = (AngehVal*)malloc(sizeof(AngehVal) * v.as.list->capacity);
    return v;
}

static AngehVal sys_print(AngehVal val) {
    if (val.type == VAL_INT) printf("%lld\n", val.as.i);
    else if (val.type == VAL_FLOAT) printf("%f\n", val.as.f);
    else if (val.type == VAL_STRING) printf("%s\n", val.as.str);
    else if (val.type == VAL_BOOL) printf("%s\n", val.as.boolean ? "true" : "false");
    else if (val.type == VAL_NIL) printf("nil\n");
    else if (val.type == VAL_LIST) printf("<list len=%d>\n", val.as.list->length);
    return make_nil();
}

static AngehVal sys_add(AngehVal a, AngehVal b) {
    if (a.type == VAL_INT && b.type == VAL_INT) return make_int(a.as.i + b.as.i);
    if (a.type == VAL_FLOAT || b.type == VAL_FLOAT) {
        double x = (a.type == VAL_INT) ? a.as.i : a.as.f;
        double y = (b.type == VAL_INT) ? b.as.i : b.as.f;
        return make_float(x + y);
    }
    return make_nil();
}

static AngehVal sys_sub(AngehVal a, AngehVal b) {
    if (a.type == VAL_INT && b.type == VAL_INT) return make_int(a.as.i - b.as.i);
    if (a.type == VAL_FLOAT || b.type == VAL_FLOAT) {
        double x = (a.type == VAL_INT) ? a.as.i : a.as.f;
        double y = (b.type == VAL_INT) ? b.as.i : b.as.f;
        return make_float(x - y);
    }
    return make_nil();
}

static AngehVal sys_intend(AngehVal intent, AngehVal data) {
    printf("🔮 [NATIVE-INTENT] Fast inferring action for: '%s'\n", intent.as.str);
    // simplistic mock for native side
    return data;
}

#endif
