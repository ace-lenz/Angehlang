import sys
import os
from interpreter import tokenize, parse_from_tokens

def to_c_expr(ast):
    if isinstance(ast, int):
        return f"make_int({ast})"
    if isinstance(ast, float):
        return f"make_float({ast})"
    if isinstance(ast, str):
        if ast.startswith('"') and ast.endswith('"'):
            return f"make_string({ast})"
        if ast == 'true': return "make_bool(1)"
        if ast == 'false': return "make_bool(0)"
        if ast == 'nil': return "make_nil()"
        # Variables: we'd need a symbol table, for now treat them as direct C identifiers.
        # Angehlang allows '-' in unquoted symbols, replace with '_'
        return ast.replace('-', '_')
    
    if isinstance(ast, list):
        if len(ast) == 0:
            return "make_nil()"
        op = ast[0]
        if op == 'print':
            return f"sys_print({to_c_expr(ast[1])})"
        if op == '+':
            return f"sys_add({to_c_expr(ast[1])}, {to_c_expr(ast[2])})"
        if op == '-':
            return f"sys_sub({to_c_expr(ast[1])}, {to_c_expr(ast[2])})"
        if op == 'def':
            var_name = ast[1].replace('-', '_')
            return f"AngehVal {var_name} = {to_c_expr(ast[2])};\n"
        if op == 'intend':
            return f"sys_intend({to_c_expr(ast[1])}, {to_c_expr(ast[2])})"
        if op == 'list':
            # rough mockup for (list a b c)
            args = ", ".join(to_c_expr(a) for a in ast[1:])
            # Actually we need proper C list init, simplified to returning empty for now
            return f"make_list({len(ast)-1})"
            
        # Function calls
        func_name = op.replace('-', '_')
        args = ", ".join(to_c_expr(a) for a in ast[1:])
        return f"{func_name}({args})"
        
    return "make_nil()"

def compile_to_c(source_code, out_filename):
    tokens = tokenize(source_code)
    asts = []
    # Similar to how interpreter runs multiple expressions
    while tokens:
        try:
            expr = parse_from_tokens(tokens)
            if expr is not None:
                asts.append(expr)
        except Exception as e:
            print(f"Warning/Error parsing: {e}")
            break

    c_code = []
    c_code.append('#include "angeh_runtime.h"')
    c_code.append('int main() {')
    
    for ast in asts:
        expr_c = to_c_expr(ast)
        if expr_c.endswith(';\n'):
            c_code.append(f"    {expr_c}")
        else:
            c_code.append(f"    {expr_c};")
            
    c_code.append('    return 0;')
    c_code.append('}')
    
    with open(out_filename, 'w', encoding='utf-8') as f:
        f.write('\n'.join(c_code))
    print(f"[AngehC] Successfully compiled to {out_filename}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python angehc.py <source.angeh>")
        sys.exit(1)
        
    in_file = sys.argv[1]
    out_file = in_file.replace('.angeh', '.c')
    with open(in_file, 'r', encoding='utf-8') as f:
        src = f.read()
    compile_to_c(src, out_file)
