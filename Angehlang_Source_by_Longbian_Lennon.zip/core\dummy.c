#include "angeh_runtime.h"
int main() {
    sys_print("Standalone);
    def_macro(unless, condition(body), make_list(3));
    unless(make_bool(0), sys_print("Macro));
    sys_intend("sort, list");
    return 0;
}